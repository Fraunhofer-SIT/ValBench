
public class DefaultPackageClass {

}
