package valbench.modellingtests;

import java.util.TreeSet;

import valbench.metadata.ValueComputationTestCase;

public class SimplestTests {
	@ValueComputationTestCase
	public static String simplestTreeSet() {
		TreeSet<String> list = new TreeSet<String>();
		list.add("a");
		return list.toString();
	}
}
