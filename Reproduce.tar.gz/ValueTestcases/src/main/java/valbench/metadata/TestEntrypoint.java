package valbench.metadata;

public @interface TestEntrypoint {

}
