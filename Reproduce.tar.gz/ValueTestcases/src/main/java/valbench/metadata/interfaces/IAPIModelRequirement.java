package valbench.metadata.interfaces;

public interface IAPIModelRequirement extends IRequirement {
	public String getDeclaringClass();
}
