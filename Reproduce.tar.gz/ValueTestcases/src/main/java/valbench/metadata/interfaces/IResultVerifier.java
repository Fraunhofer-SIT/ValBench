package valbench.metadata.interfaces;

public interface IResultVerifier {
	public IResult verifyResult(Object res);
}
