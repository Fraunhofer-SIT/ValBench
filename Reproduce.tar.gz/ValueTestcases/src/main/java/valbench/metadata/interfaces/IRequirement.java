package valbench.metadata.interfaces;

public interface IRequirement {

}
