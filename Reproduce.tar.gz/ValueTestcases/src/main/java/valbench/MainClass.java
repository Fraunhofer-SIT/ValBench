package valbench;

public class MainClass {

	public static void main(String[] args) {
		//Gets filled via the CreateJavaEntyPoint-Test upon building
		System.err.println("WARNING: This main method is *not* intended to actually run.");
		System.err.println("It can be used by Code analysis tools.");
		System.err.println("Some test cases use random coin flips to throw exceptions occasionally.");
	}
}
