package valbench.base;

import android.view.View;

public class R {
	public static final class layout {

		public static View activity_main;
		
	}
	public static final class raw {

		public static int androidres;
		
	}
	public static final class id {

		public static int txtOutput;
		
	}
	
}
