To run Violist on Java Application, follow the structure of the Violist/Java/bookstore folder.
Command line:
java -jar Violist_Java.jar /usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar ~Violist/Java/bookstore /classlist.txt

To run Violist on Android Application, follow the structure of the Violist/Android folder.
Command line:
java -jar Violist_Android.jar path/Violist/Android path/Violist/Android/App1 /a2z.Mobile.DevConnections.txt /a2z.Mobile.DevConnections.instrumented.apk
