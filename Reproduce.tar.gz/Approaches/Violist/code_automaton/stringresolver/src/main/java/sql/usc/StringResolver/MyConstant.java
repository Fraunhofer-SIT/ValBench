package sql.usc.StringResolver;

public class MyConstant {
static public final int type_string=0;
static public final int type_int=1;
static public final int type_double=2;
static public final int type_boolean=3;
static public final int type_obj=4;
static public final int type_arr=5;
static public final int type_multiarr=6;

static public final int opcode_assign=7;

static public final long UNKNOWN_INT=Long.MIN_VALUE;
static public final double UNKNOWN_DOUBLE=Double.MIN_VALUE;



}
