package sql.usc.StringResolver;

import java.util.HashSet;
import java.util.Set;

import soot.Unit;

public class Relience {
	public  Unit u;
	public Set<Definition> rely=new HashSet<Definition>();
}
