package wam.configuration;

public class ConfMainMethod {
		public String classname;
		public String subsig;
}
