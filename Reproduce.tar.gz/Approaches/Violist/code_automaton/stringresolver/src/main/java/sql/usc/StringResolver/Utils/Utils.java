package sql.usc.StringResolver.Utils;

public class Utils { 
	public static void Log(String m)
	{
		System.out.println(m);
	}
}
