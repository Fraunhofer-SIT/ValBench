# Violist: A String analysis framework for Java and Android apps

executable: our executable file and some market test cases

testcases: all of our test cases

We follow GPL license
