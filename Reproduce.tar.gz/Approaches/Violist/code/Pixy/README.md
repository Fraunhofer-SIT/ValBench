We took the JAR from https://github.com/marapapman/Violist/tree/master

You can install it via

```
mvn org.apache.maven.plugins:maven-install-plugin:3.1.1:install-file -DgroupId=pixy -DartifactId=pixy -Dversion=1.0.0 -Dpackaging=jar -Dfile=Pixy.jar
```
