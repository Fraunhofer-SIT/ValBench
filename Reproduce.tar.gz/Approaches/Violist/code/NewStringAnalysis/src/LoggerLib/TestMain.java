package LoggerLib;

public class TestMain {
public static void main(String argv[])
{
	Logger.increase(3);
	Logger.reportString("aa","bb");
}
}
