package usc.sql.string;

public class AndroidMain {

	public static void main(String[] args) {
		
		JavaAndroid ja = new JavaAndroid(args[0],args[1],args[2]);
	}
}
