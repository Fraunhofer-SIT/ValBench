package usc.sql.string;

public class JavaMain {

	public static void main(String[] args) {
		
		JavaAndroid ja= new JavaAndroid(args[0],args[1]);
		
	}

}
