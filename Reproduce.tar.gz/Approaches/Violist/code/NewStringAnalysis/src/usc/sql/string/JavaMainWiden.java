package usc.sql.string;

public class JavaMainWiden {

	public static void main(String[] args) {
		
		JavaAndroidWiden ja= new JavaAndroidWiden(args[0],args[1]);
	}

}
