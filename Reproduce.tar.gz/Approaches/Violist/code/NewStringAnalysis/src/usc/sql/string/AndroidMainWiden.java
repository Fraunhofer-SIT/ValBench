package usc.sql.string;

public class AndroidMainWiden {

	public static void main(String[] args) {
		
		JavaAndroidWiden ja = new JavaAndroidWiden(args[0],args[1],args[2]);
	}
}
