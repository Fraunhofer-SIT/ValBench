package usc.sql.string.testcase;

public class Switch {
	public static void main(String[] args) {
		String a="Hi";
		int flag=0;
		switch(flag){
		case 1: a+="1";
		case 2: a+="2";
		case 3: a+="3";
		case 4: a+="4";
		case 5: a+="5";
		default: a+="0";
		}
	}
}
