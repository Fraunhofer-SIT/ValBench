package usc.sql.string.ding;

public class StringValueTest {
	public static void main(String argv[])
	{
		ToolKit.Display("./target/classes","usc/sql/string/testcase/SimpleTest.class","<usc.sql.string.testcase.IRTestCase: void main(java.lang.String[])>");

	}
}
