# StringHound

In order to use StringHound you have to execute in your bash the command 
'cat hashDict_aa hashDict_ab hashDict_ac hashDict_ad hashDict_ae hashDict_af > hashDict.txt' in the folder 'analysis' 
and the main method in the file analysis/src/main/scala/main/StringDecryption.scala.
