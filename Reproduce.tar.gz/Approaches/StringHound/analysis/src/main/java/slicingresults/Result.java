package slicingresults;
    
    public class Result {
  	  public String method;
  	  public String value;

        public Result(String method, String value) {
            this.method = method;
            this.value = value;
        }
    }