String Analysis for the COAL Solver
===================================

See [http://siis.cse.psu.edu/coal/](http://siis.cse.psu.edu/coal/) for information about the COAL solver.
