package valbench.eval;

import java.io.File;

public class Inputs {

	public final File jar, apk, singleTestCaseJars, rtJar, java8;

	public Inputs() {
		String base = "../ValueTestcases/target";
		jar = new File(base, "valbench-testcases-0.0.1-SNAPSHOT.jar");
		apk = new File(base, "valbench-testcases-android.apk");
		singleTestCaseJars = new File(base, "single-testcase-jars");
		
		//StringHound only runs on Java 8
		java8 = getEnv("JAVA8", "/usr/lib/jvm/java-8-openjdk-amd64/bin/java");
		
		rtJar = getEnv("RT_JAR", "/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar");
		for (File f : new File[] { jar, apk, singleTestCaseJars,rtJar  }) {
			if (!f.exists())
				throw new RuntimeException(String.format("%s does not exist", f.getAbsolutePath()));
		}
	}

	private File getEnv(String env, String defaultVal) {
		String e = System.getenv(env);
		if (e == null)
			e = defaultVal;
		return new File(e);
	}

	public File[] getSingleTestCaseJars() {
		return singleTestCaseJars.listFiles();
	}
	
}
