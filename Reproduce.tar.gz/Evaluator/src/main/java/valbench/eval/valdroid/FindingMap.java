package valbench.eval.valdroid;

import java.util.ArrayList;
import java.util.List;

public class FindingMap {
	public List<Finding> findings = new ArrayList<>();
}
