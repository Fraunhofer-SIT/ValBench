package valbench.eval.valdroid;

public class Finding {

	public String variable;
	public String value;
	public boolean imprecise;

}
