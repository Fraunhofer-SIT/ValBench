package valbench.eval.valdroid;

import java.util.ArrayList;
import java.util.List;

public class App {

	public List<ProgramLocation> programLocations = new ArrayList<ProgramLocation>();

}
