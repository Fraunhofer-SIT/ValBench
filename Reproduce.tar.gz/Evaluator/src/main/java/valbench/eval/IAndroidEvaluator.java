package valbench.eval;

public interface IAndroidEvaluator extends IEvaluator {

}
