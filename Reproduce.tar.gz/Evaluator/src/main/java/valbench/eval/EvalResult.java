package valbench.eval;

import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import valbench.eval.utils.CounterMap;
import valbench.metadata.StatisticResultsAggregator;
import valbench.metadata.interfaces.IRequirement;
import valbench.metadata.interfaces.IResult;

public class EvalResult {
	private final StatisticResultsAggregator aggregated;
	private IEvaluator evaluator;
	private List<IResult> results;
	
	public EvalResult(IEvaluator eval, List<IResult> results) {
		this.evaluator = eval;
		aggregated = new StatisticResultsAggregator(results);
		this.results = results;
	}

	public StatisticResultsAggregator getStatistics() {
		return aggregated;
	}

	public void printMostIncorrect() {
		System.out.println("Most incorrect for " + evaluator.getName());
		CounterMap<IRequirement> reqMissing = new CounterMap<>(); 
		CounterMap<IRequirement> reqCorrect = new CounterMap<>(); 
		
			
		for (IResult d : results) 
		{
			if (d.falseNegatives() > 0 || d.falsePositives() > 0) {
				for (IRequirement p : d.getTestCase().getRequirements())
					reqMissing.count(p);
			} else
			{
				for (IRequirement p : d.getTestCase().getRequirements()) {
					reqCorrect.count(p);
				}
			}
		}
		for (Entry<IRequirement, Integer> p : reqCorrect) {
			reqMissing.set(p.getKey(), 0);
		}
		Iterator<Entry<IRequirement, Integer>> m = reqMissing.sortedValues().iterator();
		for (int i = 1; i < 10; i++) {
			Entry<IRequirement, Integer> r = m.next();
			System.out.println(r.getKey() + ": " + r.getValue());
		}
		System.out.println();
		
	}

}
